var electron = require('electron');
var app = electron.app;
var BrowserWindow = electron.BrowserWindow;

// Quit when all windows are closed.
app.on('window-all-closed', function() {
	app.quit();
});

app.on('ready', function() {
	var mainWindow = new BrowserWindow({
		width: 800,
		height: 600,
		frame: false,
	});
	mainWindow.loadURL('file://' + __dirname + '/index.html');
	mainWindow.focus();
	mainWindow.maximize();
});
