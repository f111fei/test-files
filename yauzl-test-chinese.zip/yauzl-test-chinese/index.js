var yauzl = require("yauzl");
var fs = require("fs");
var path = require("path");
var mkdirp = require("mkdirp"); // or similar

yauzl.open("chinese.zip", { lazyEntries: true }, function (err, zipfile) {
	if (err) throw err;
	zipfile.readEntry();
	zipfile.on("entry", function (entry) {
		console.log('Current FileName: ' + entry.fileName);
		if (/\/$/.test(entry.fileName)) {
			// directory file names end with '/'
			mkdirp(entry.fileName, function (err) {
				if (err) throw err;
				zipfile.readEntry();
			});
		} else {
			// file entry
			zipfile.openReadStream(entry, function (err, readStream) {
				if (err) throw err;
				// ensure parent directory exists
				mkdirp(path.dirname(entry.fileName), function (err) {
					if (err) throw err;
					readStream.pipe(fs.createWriteStream(entry.fileName));
					readStream.on("end", function () {
						zipfile.readEntry();
					});
				});
			});
		}
	});
});